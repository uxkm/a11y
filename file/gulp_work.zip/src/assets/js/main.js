import {random} from './util';

const randomOne = random(10);
const randomTwo = random(20);

console.log( `${randomOne} ${randomTwo}` );